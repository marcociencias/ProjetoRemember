package DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import com.example.alarme.ResponsavelActivity;

import java.util.ArrayList;
import java.util.List;

import ContextoBD.Contexto;
import Modelo.Responsavel;

public class ResponsavelDAO extends Contexto {
    public ResponsavelDAO(@Nullable Context context) {
        super(context);
    }

    public void insere(Responsavel responsavel , long Fk_id_login) {
        ContentValues dados = getContentValuesAluno(responsavel, Fk_id_login);

        final SQLiteDatabase readableDatabase = getReadableDatabase();
        readableDatabase.insert("Responsavel",null,dados);
    }

    private ContentValues getContentValuesAluno(Responsavel responsavel , long Fk_id_login) {
        ContentValues dados = new ContentValues();
        dados.put("nome",responsavel.getNome());
        dados.put("endereco",responsavel.getEndereco());
        dados.put("telefone",responsavel.getTelefone());
        dados.put("email",responsavel.getEmail());
        dados.put("grau_parentesco",responsavel.getGrau_Parentesco());
        dados.put("fk_id_paciente",Fk_id_login);
        return dados;
    }

    public List<Responsavel> buscarResponsavel() {

        String sql = "SELECT * FROM Responsavel";
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(sql,null);
        List<Responsavel> ListaResponsavel = new ArrayList<Responsavel>();

        while(c.moveToNext())
        {
            Responsavel responsavel = new Responsavel();
            responsavel.setFk_responsavel(c.getLong(c.getColumnIndex("fk_id_paciente")));
            responsavel.setId(c.getLong(c.getColumnIndex("id")));
            responsavel.setNome(c.getString(c.getColumnIndex("nome")));
            responsavel.setEndereco(c.getString(c.getColumnIndex("endereco")));
            responsavel.setTelefone(c.getString(c.getColumnIndex("telefone")));
            responsavel.setEmail(c.getString(c.getColumnIndex("email")));
            responsavel.setGrau_Parentesco(c.getString(c.getColumnIndex("grau_parentesco")));
            ListaResponsavel.add(responsavel);
        }
        c.close();
        return ListaResponsavel;
    }

    public String getResponsavel(long idResponsavel)
    {
        SQLiteDatabase db = getWritableDatabase();
        String[] params = {String.valueOf(idResponsavel)};
        String sql = "Select * From Responsavel where fk_id_paciente = ?";
        Cursor c = db.rawQuery(sql,params);
        Responsavel rp = new Responsavel();
        if(c != null) {
            if (c.moveToNext()) {
                rp.setTelefone(c.getString(c.getColumnIndex("telefone")));
            }
            return rp.getTelefone();
        }else
        {
            return null;
        }
    }

}
