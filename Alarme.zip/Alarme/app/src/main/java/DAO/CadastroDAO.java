package DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import ContextoBD.Contexto;
import Modelo.Cadastro;
import Modelo.Login;

public class CadastroDAO extends Contexto {
    public CadastroDAO(@Nullable Context context) {
        super(context);
    }

    public void insere(Cadastro cadastro) {
        ContentValues dados = getContentValuesLogin(cadastro);
        final SQLiteDatabase readableDatabase = getReadableDatabase();
        readableDatabase.insert("Login",null,dados);
    }

    private ContentValues getContentValuesLogin(Cadastro cadastro) {
        ContentValues dados = new ContentValues();
        dados.put("usuario",cadastro.getUsuario());
        dados.put("senha",cadastro.getSenha());
        return dados;
    }

    public long getIdLogin(Cadastro cadastro)
    {
        SQLiteDatabase db = getWritableDatabase();
        String[] params = {cadastro.getUsuario(),cadastro.getSenha()};
        String sql = "Select * From Login where Usuario = ? and Senha = ?";
        Cursor c = db.rawQuery(sql,params);
        Cadastro cd = new Cadastro();
        if(c.moveToNext()) {
            cd.setId(c.getLong(c.getColumnIndex("id")));
        }
        return cd.getId();
    }
}
