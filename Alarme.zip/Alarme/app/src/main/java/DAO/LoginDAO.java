package DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import ContextoBD.Contexto;
import Modelo.Cadastro;
import Modelo.Login;

public class LoginDAO extends Contexto {
    public LoginDAO(@Nullable Context context) {
        super(context);
    }

    public void insere(Login login) {
        ContentValues dados = getContentValuesLogin(login);
        final SQLiteDatabase readableDatabase = getReadableDatabase();
        readableDatabase.insert("Login",null,dados);
    }

    private ContentValues getContentValuesLogin(Login login) {
        ContentValues dados = new ContentValues();
        dados.put("Usuario",login.getUsuario());
        dados.put("Senha",login.getSenha());
        return dados;
    }

    public List<Login> buscaLogin() {

        String sql = "SELECT * FROM Login";
        SQLiteDatabase db = getReadableDatabase();
        Cursor cursor = db.rawQuery(sql,null);
        List<Login> ListLogin = new ArrayList<Login>();

        while(cursor.moveToNext())
        {
            Login logar = new Login();
            logar.setId(cursor.getLong(cursor.getColumnIndex("id")));
            logar.setUsuario(cursor.getString(cursor.getColumnIndex("Usuario")));
            logar.setSenha(cursor.getString(cursor.getColumnIndex("Senha")));
            ListLogin.add(logar);
        }
        cursor.close();
        return ListLogin;
    }

    public long getIdLogin(Login login)
    {
        SQLiteDatabase db = getWritableDatabase();
        String[] params = {login.getUsuario(),login.getSenha()};
        String sql = "Select * From Login where Usuario = ? and Senha = ?";
        Cursor c = db.rawQuery(sql,params);
        Cadastro cd = new Cadastro();
        if(c != null) {
            if (c.moveToNext()) {
                cd.setId(c.getLong(c.getColumnIndex("id")));
            }
            return cd.getId();
        }else
        {
            return 0;
        }
    }

}
