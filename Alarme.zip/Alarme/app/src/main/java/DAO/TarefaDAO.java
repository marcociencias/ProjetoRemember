package DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import ContextoBD.Contexto;
import Modelo.Paciente;
import Modelo.Tarefas;

public class TarefaDAO extends Contexto {
    public TarefaDAO(@Nullable Context context) {
        super(context);
    }

    public void insere(Tarefas tarefa , long id_logado) {
        ContentValues dados = getContentValuesAluno(tarefa ,id_logado);

        final SQLiteDatabase readableDatabase = getReadableDatabase();
        readableDatabase.insert("Tarefas",null,dados);
    }

    private ContentValues getContentValuesAluno(Tarefas tarefa , long id_logado) {
        ContentValues dados = new ContentValues();
        dados.put("fk_id_logado",id_logado);
        dados.put("tarefa",tarefa.getTipo());
        dados.put("horario",tarefa.getHorario());
        dados.put("descricao",tarefa.getDescricao());
        return dados;
    }

    public void deletar(Tarefas tarefas) {

        SQLiteDatabase db = getWritableDatabase();
        String[] params = {String.valueOf(tarefas.getId())};
        db.delete("Tarefas","id = ?",params);
    }

    public List<Tarefas> bucarTarefas(long id_logado) {

        SQLiteDatabase db = getReadableDatabase();
        String [] params = {String.valueOf(id_logado)};
        String sql = "SELECT * FROM Tarefas where fk_id_logado = ?";
        Cursor c = db.rawQuery(sql,params);
        List<Tarefas> ListTarefas = new ArrayList<Tarefas>();

        while(c.moveToNext())
        {
            Tarefas tarefa = new Tarefas();
            tarefa.setId(c.getLong(c.getColumnIndex("id")));
            tarefa.setFk_id_logado(c.getLong(c.getColumnIndex("fk_id_logado")));
            tarefa.setTipo(c.getString(c.getColumnIndex("tarefa")));
            tarefa.setHorario(c.getString(c.getColumnIndex("horario")));
            tarefa.setDescricao(c.getString(c.getColumnIndex("descricao")));
            ListTarefas.add(tarefa);
        }
        c.close();
        return ListTarefas;
    }

    public void alterar(Tarefas tarefa) {

        SQLiteDatabase db = getWritableDatabase();
        ContentValues dados = getContentValuesAluno(tarefa , tarefa.getFk_id_logado());

        String [] params = {tarefa.getId().toString()};
        db.update("Tarefas",dados,"id = ?",params);
    }

}
