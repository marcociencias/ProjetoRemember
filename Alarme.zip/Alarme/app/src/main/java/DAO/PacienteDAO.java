package DAO;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

import ContextoBD.Contexto;
import Modelo.Paciente;
import Modelo.Responsavel;

public class PacienteDAO extends Contexto {
    public PacienteDAO(@Nullable Context context) {
        super(context);
    }
    public void insere(Paciente paciente , long fk_login) {
        ContentValues dados = getContentValuesAluno(paciente ,fk_login);

        final SQLiteDatabase readableDatabase = getReadableDatabase();
        readableDatabase.insert("Paciente",null,dados);
    }

    private ContentValues getContentValuesAluno(Paciente paciente , long fk_login) {
        ContentValues dados = new ContentValues();
        dados.put("fk_id_login",fk_login);
        dados.put("nome",paciente.getNome());
        dados.put("endereco",paciente.getEndereco());
        dados.put("dataNascimento",paciente.getDataDeNascimento());
        dados.put("cpf",paciente.getCpf());
        dados.put("tipoSanguineo",paciente.getTipoSanguineo());
        return dados;
    }

    public List<Paciente> buscarPaciente() {

        String sql = "SELECT * FROM Paciente";
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.rawQuery(sql,null);
        List<Paciente> ListaPaciente = new ArrayList<Paciente>();

        while(c.moveToNext())
        {
            Paciente paciente = new Paciente();
            paciente.setFk_login(c.getLong(c.getColumnIndex("fk_id_login")));
            paciente.setId(c.getLong(c.getColumnIndex("id")));
            paciente.setNome(c.getString(c.getColumnIndex("nome")));
            paciente.setEndereco(c.getString(c.getColumnIndex("endereco")));
            paciente.setDataDeNascimento(c.getString(c.getColumnIndex("dataNascimento")));
            paciente.setCpf(c.getString(c.getColumnIndex("cpf")));
            paciente.setTipoSanguineo(c.getString(c.getColumnIndex("tipoSanguineo")));
            ListaPaciente.add(paciente);
        }
        c.close();
        return ListaPaciente;
    }

}
