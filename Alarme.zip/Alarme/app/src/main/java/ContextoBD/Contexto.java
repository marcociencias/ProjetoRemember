package ContextoBD;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import androidx.annotation.Nullable;

public class Contexto extends SQLiteOpenHelper {

    public Contexto(@Nullable Context context) {
        super(context, "Agenda",null, 8);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("CREATE TABLE Login (id INTEGER PRIMARY KEY, Usuario TEXT, Senha TEXT);");
        sqLiteDatabase.execSQL("CREATE TABLE Paciente (id INTEGER PRIMARY KEY, fk_id_login long, nome TEXT NOT NULL, endereco TEXT, dataNascimento TEXT,cpf TEXT,tipoSanguineo TEXT); ");
        sqLiteDatabase.execSQL("CREATE TABLE Responsavel (id INTEGER PRIMARY KEY, fk_id_paciente long, nome TEXT NOT NULL, endereco TEXT, telefone TEXT,email TEXT,grau_parentesco TEXT); ");
        sqLiteDatabase.execSQL("CREATE TABLE Tarefas (id INTEGER PRIMARY KEY, fk_id_logado long, tarefa TEXT NOT NULL, horario TEXT, descricao TEXT); ");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Tarefas");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Login");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Responsavel");
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS Paciente");
        onCreate(sqLiteDatabase);
    }

}
