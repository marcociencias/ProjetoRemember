package Modelo;

import java.io.Serializable;

public class Tarefas implements Serializable {

    private Long Id;
    private Long fk_id_logado;
    private String Tipo;
    private String Horario;
    private String Descricao;

    public Long getId() {
        return Id;
    }

    public void setId(Long id) {
        Id = id;
    }
    public Long getFk_id_logado() {
        return fk_id_logado;
    }

    public void setFk_id_logado(Long fk_id_logado) {
        this.fk_id_logado = fk_id_logado;
    }

    public String getTipo() {
        return Tipo;
    }

    public void setTipo(String tipo) {
        Tipo = tipo;
    }

    public String getHorario() {
        return Horario;
    }

    public void setHorario(String horario) {
        Horario = horario;
    }

    public String getDescricao() {
        return Descricao;
    }

    public void setDescricao(String descricao) {
        Descricao = descricao;
    }

    @Override
    public String toString() {
        return   "Tipo ='" + Tipo + '\'' +
                "\n Horario ='" + Horario + '\'' +
                "\n Descricao ='" + Descricao + '\'';
    }
}
