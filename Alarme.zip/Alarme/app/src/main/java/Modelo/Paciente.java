package Modelo;

import java.io.Serializable;

public class Paciente implements Serializable {

    private long Id;
    private long fk_login;
    private String Nome;
    private String Endereco;
    private String Cpf;
    private String DataDeNascimento;
    private String TipoSanguineo;

    public long getId() {
        return Id;
    }

    public long getFk_login() {
        return fk_login;
    }

    public void setFk_login(long fk_login) {
        this.fk_login = fk_login;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public String getCpf() {
        return Cpf;
    }

    public void setCpf(String cpf) {
        Cpf = cpf;
    }

    public String getDataDeNascimento() {
        return DataDeNascimento;
    }

    public void setDataDeNascimento(String dataDeNascimento) {
        DataDeNascimento = dataDeNascimento;
    }

    public String getTipoSanguineo() {
        return TipoSanguineo;
    }

    public void setTipoSanguineo(String tipoSanguineo) {
        TipoSanguineo = tipoSanguineo;
    }

    @Override
    public String toString() {
        return "Paciente{" +
                "Id=" + Id +
                ", fk_login=" + fk_login +
                ", Nome='" + Nome + '\'' +
                ", Endereco='" + Endereco + '\'' +
                ", Cpf='" + Cpf + '\'' +
                ", DataDeNascimento='" + DataDeNascimento + '\'' +
                ", TipoSanguineo='" + TipoSanguineo + '\'' +
                '}';
    }
}
