package Modelo;

import java.io.Serializable;

public class Cadastro implements Serializable {

    private long Id;
    private String Usuario;
    private String Senha;

    public long getId() {
        return Id;
    }

    public void setId(long id) {
        Id = id;
    }

    public String getUsuario() {
        return Usuario;
    }

    public void setUsuario(String usuario) {
        Usuario = usuario;
    }

    public String getSenha() {
        return Senha;
    }

    public void setSenha(String senha) {
        Senha = senha;
    }

    @Override
    public String toString() {
        return "Login{" +
                "Id=" + Id +
                ", Usuario='" + Usuario + '\'' +
                ", Senha='" + Senha + '\'' +
                '}';
    }
}
