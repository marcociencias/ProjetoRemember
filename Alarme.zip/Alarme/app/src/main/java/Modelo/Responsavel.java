package Modelo;

public class Responsavel {

    private Long id;
    private Long fk_responsavel;
    private String Nome;
    private String Endereco;
    private String Telefone;
    private String Email;
    private String Grau_Parentesco;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getFk_responsavel() {
        return fk_responsavel;
    }

    public void setFk_responsavel(Long fk_responsavel) {
        this.fk_responsavel = fk_responsavel;
    }

    public String getNome() {
        return Nome;
    }

    public void setNome(String nome) {
        Nome = nome;
    }

    public String getEndereco() {
        return Endereco;
    }

    public void setEndereco(String endereco) {
        Endereco = endereco;
    }

    public String getTelefone() {
        return Telefone;
    }

    public void setTelefone(String telefone) {
        Telefone = telefone;
    }

    public String getEmail() {
        return Email;
    }

    public void setEmail(String email) {
        Email = email;
    }

    public String getGrau_Parentesco() {
        return Grau_Parentesco;
    }

    public void setGrau_Parentesco(String grau_Parentesco) {
        Grau_Parentesco = grau_Parentesco;
    }

    @Override
    public String toString() {
        return "Responsavel{" +
                "id=" + id +
                ", fk_responsavel=" + fk_responsavel +
                ", Nome='" + Nome + '\'' +
                ", Endereco='" + Endereco + '\'' +
                ", Telefone='" + Telefone + '\'' +
                ", Email='" + Email + '\'' +
                ", Grau_Parentesco='" + Grau_Parentesco + '\'' +
                '}';
    }
}
