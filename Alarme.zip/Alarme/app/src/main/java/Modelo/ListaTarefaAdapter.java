package Modelo;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.example.alarme.R;

import java.util.List;

public class ListaTarefaAdapter extends BaseAdapter {

    private Context contexto;
    private List<Tarefas> listTarefa;

    public ListaTarefaAdapter(Context contexto, List<Tarefas> listTarefa) {
        this.contexto = contexto;
        this.listTarefa = listTarefa;
    }

    @Override
    public int getCount() {
        return listTarefa.size();
    }

    @Override
    public Object getItem(int i) {
        return listTarefa.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {

        View v = View.inflate(contexto,R.layout.activity_item_tarefas,null);

        TextView txtTipo = (TextView)v.findViewById(R.id.tipo);
        TextView txtHorario = (TextView)v.findViewById(R.id.horario);
        TextView txtDescricao = (TextView)v.findViewById(R.id.descricao);
        ImageView imagem = (ImageView)v.findViewById((R.id.lista_curso_personalizada_imagem));

        txtTipo.setText(listTarefa.get(i).getTipo());
        txtHorario.setText(listTarefa.get(i).getHorario());
        txtDescricao.setText(listTarefa.get(i).getDescricao());

        if(txtTipo.getText().equals("Remedio"))
        {
            imagem.setImageResource(R.drawable.remedio);
        }
        else if(txtTipo.getText().equals("Cafe da Tarde") || txtTipo.getText().equals("Cafe da Manha"))
        {
            imagem.setImageResource(R.drawable.cafepq);
        }
        else if(txtTipo.getText().equals("Jantar") || txtTipo.getText().equals("Almoco"))
        {
            imagem.setImageResource(R.drawable.jantar);
        }


        v.setTag(listTarefa.get(i).getId());

        return v;
    }
}
