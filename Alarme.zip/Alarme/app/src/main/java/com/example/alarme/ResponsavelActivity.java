package com.example.alarme;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;
import java.util.List;
import DAO.CadastroDAO;
import DAO.LoginDAO;
import DAO.PacienteDAO;
import DAO.ResponsavelDAO;
import Modelo.Cadastro;
import Modelo.Login;
import Modelo.Paciente;
import Modelo.Responsavel;

public class ResponsavelActivity extends AppCompatActivity{

    ResponsavelHelper helper;
    Responsavel responsavel;
    Paciente pc;
    Cadastro cd;
    CadastroDAO cadDao;
    PacienteDAO pacDao;
    ResponsavelDAO respDao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        helper = new ResponsavelHelper(ResponsavelActivity.this);

        Intent intent = getIntent();
        pc = (Paciente) intent.getSerializableExtra("paciente");
        cd = (Cadastro) intent.getSerializableExtra("cadastro");

    }

    public void CadastrarResponsavel(View view) {
        ResponsavelDAO Respdao = new ResponsavelDAO(this);
        responsavel = new Responsavel();
        responsavel = helper.GetResponsavel();

        if(responsavel.getNome().equals("") || responsavel.getEndereco().equals("") || responsavel.getTelefone().equals("") ||
           responsavel.getEmail().equals(""))
        {
            Toast.makeText(this, "Preencher todos os campos !!!!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            //INICIO DE INSERÇÃO DE DADOS DO CADASTRO
            //insere o cadastro "login"
            cadDao = new CadastroDAO(this);
            cadDao.insere(cd);
            //retorna o id do login para o paciente
            CadastroDAO consulta= new CadastroDAO(this);
            long a  = consulta.getIdLogin(cd);
            //insere o paciente com o id do login
            pacDao = new PacienteDAO(this);
            pacDao.insere(pc,a);
            //inserir o responsavel com o id do login
            Respdao.insere(responsavel, a);
            //Cadastro finalizado
            Toast.makeText(this, "Cadastro realizado com sucesso", Toast.LENGTH_SHORT).show();

            Intent intent = new Intent(ResponsavelActivity.this,LoginActivity.class);
            startActivity(intent);

        }
    }

    public void TesteBanco(View view) {
        LoginDAO dao= new LoginDAO(this);
        List<Login> resp = dao.buscaLogin();

        for(int i = 0; i < resp.size(); i++)
        {
            Toast.makeText(this,"valores : " + resp.get(i),Toast.LENGTH_SHORT).show();
        }
    }

    public void ListagemDePacientes(View view) {
        PacienteDAO dao= new PacienteDAO(this);
        List<Paciente> resp = dao.buscarPaciente();

        for(int i = 3; i < resp.size(); i++)
        {
            Toast.makeText(this,"total = " +resp.size(),Toast.LENGTH_LONG).show();
            Toast.makeText(this,"FK_LOGIN : " + resp.get(i).getFk_login(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"NOME : " + resp.get(i).getNome(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"ENDERECO : " + resp.get(i).getEndereco(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"DATA NASCIMENTO : " + resp.get(i).getDataDeNascimento(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"CPF : " + resp.get(i).getCpf(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"TIPO SANGUINEO : " + resp.get(i).getTipoSanguineo(),Toast.LENGTH_SHORT).show();
        }
    }

    public void ListagemDeResponsaveis(View view)
    {
        ResponsavelDAO dao = new ResponsavelDAO(this);
        List<Responsavel> resp = dao.buscarResponsavel();

        for(int i = 0 ; i < resp.size(); i++)
        {
            Toast.makeText(this,"total = " +resp.size(),Toast.LENGTH_LONG).show();
            Toast.makeText(this,"FK_LOGIN : " + resp.get(i).getFk_responsavel(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"NOME : " + resp.get(i).getNome(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"ENDERECO : " + resp.get(i).getEndereco(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"GRAU PARENTESCO : " + resp.get(i).getGrau_Parentesco(),Toast.LENGTH_SHORT).show();
            Toast.makeText(this,"TELEFONE : " + resp.get(i).getTelefone(),Toast.LENGTH_SHORT).show();

        }

    }


    public long ObterId(View view)
    {
        CadastroDAO dao= new CadastroDAO(this);
        long a  = dao.getIdLogin(cd);
        Toast.makeText(this,"Id = " + a ,Toast.LENGTH_SHORT).show();
        return a;
    }

}
