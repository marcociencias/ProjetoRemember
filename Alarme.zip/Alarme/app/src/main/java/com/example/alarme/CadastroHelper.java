package com.example.alarme;
import android.widget.EditText;
import Modelo.Cadastro;

public class CadastroHelper {

    private final EditText usuario;
    private final EditText senha;
    private Cadastro cadastro;

    public CadastroHelper(CadastroActivity cd)
    {
        usuario = cd.findViewById(R.id.usuarioC);
        senha = cd.findViewById(R.id.senhaC);
        cadastro =  new Cadastro();
    }

    public Cadastro pegaCadastro()
    {
        cadastro.setUsuario(usuario.getText().toString());
        cadastro.setSenha((senha.getText().toString()));
        return cadastro;
    }
}
