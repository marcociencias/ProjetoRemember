package com.example.alarme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import java.util.List;

import DAO.PacienteDAO;
import DAO.ResponsavelDAO;
import Modelo.Cadastro;
import Modelo.Paciente;
import Modelo.Responsavel;

public class PacienteActivity extends AppCompatActivity {

    PacienteHelper helper;
    Intent intent;
    Paciente pc;
    Cadastro cadastro;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_paciente);
        helper = new PacienteHelper(PacienteActivity.this);
        intent = getIntent();
        cadastro = (Cadastro) intent.getSerializableExtra("cadastro");
    }

    public void CadastrarPaciente(View view) {
        PacienteDAO dao = new PacienteDAO(this);
        pc = new Paciente();
        pc = helper.obterPaciente();

        if(pc.getNome().equals("") || pc.getEndereco().equals("") || pc.getDataDeNascimento().equals("") || pc.getCpf().equals(""))
        {
            Toast.makeText(this, "Preencher todos os campos !!!!", Toast.LENGTH_SHORT).show();
        }
        else
        {
            Toast.makeText(this, "Paciente preenchido com sucesso" + pc.getNome() , Toast.LENGTH_SHORT).show();
            Intent intent = new Intent(PacienteActivity.this , ResponsavelActivity.class);
            intent.putExtra("paciente",pc);
            intent.putExtra("cadastro",cadastro);
            startActivity(intent);
        }
    }
}
