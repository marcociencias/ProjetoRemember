package com.example.alarme;

import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;

import Modelo.Responsavel;

public class ResponsavelHelper {

    private EditText Nome;
    private EditText Endereco;
    private EditText Telefone;
    private EditText Email;
    private Spinner Grau_Parentesco;
    Responsavel responsavel;

    public ResponsavelHelper(ResponsavelActivity main)
    {
        Nome = main.findViewById(R.id.txtResponsavel);
        Endereco = main.findViewById(R.id.txtEndereco);
        Telefone = main.findViewById(R.id.txtTelefone);

        SimpleMaskFormatter smf = new SimpleMaskFormatter("(NN)NNNNN - NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(Telefone, smf);
        Telefone.addTextChangedListener(mtw);
        Email = main.findViewById(R.id.txtEmail);

        Grau_Parentesco = main.findViewById(R.id.grau_parentesco);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(main, R.array.planets_array, android.R.layout.simple_spinner_item);
        Grau_Parentesco.setAdapter(adapter);

        responsavel = new Responsavel();
    }

    public Responsavel GetResponsavel()
    {
        responsavel.setNome(Nome.getText().toString());
        responsavel.setEndereco(Endereco.getText().toString());
        responsavel.setTelefone(Telefone.getText().toString());
        responsavel.setEmail(Email.getText().toString());
        responsavel.setGrau_Parentesco(Grau_Parentesco.getSelectedItem().toString());
        return responsavel;
    }

}
