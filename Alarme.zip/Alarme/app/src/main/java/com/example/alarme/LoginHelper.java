package com.example.alarme;

import android.widget.EditText;

import Modelo.Login;

public class LoginHelper {

    private final EditText usuario;
    private final EditText senha;
    private Login logar;

    public LoginHelper(LoginActivity login)
    {
        usuario = login.findViewById(R.id.usuario);
        senha = login.findViewById(R.id.senha);
        logar =  new Login();
    }

    public Login pegaLogin()
    {
        logar.setUsuario(usuario.getText().toString());
        logar.setSenha((senha.getText().toString()));
        return logar;
    }
}
