package com.example.alarme;

import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;

import Modelo.Paciente;

public class PacienteHelper {

    private EditText Nome;
    private EditText Endereco;
    private EditText DataDeNascimento;
    private EditText Cfp;
    private Spinner TipoSanguineo;
    Paciente ps;

    public PacienteHelper(PacienteActivity paciente)
    {
        Nome = paciente.findViewById(R.id.txtPaciente);
        Endereco = paciente.findViewById(R.id.txtEndereco);
        DataDeNascimento = paciente.findViewById(R.id.txtDtNascimento);

        SimpleMaskFormatter smf = new SimpleMaskFormatter("NN/NN/NNNN");
        MaskTextWatcher mtw = new MaskTextWatcher(DataDeNascimento, smf);
        DataDeNascimento.addTextChangedListener(mtw);

        Cfp = paciente.findViewById(R.id.txtCpf);

        SimpleMaskFormatter smfc = new SimpleMaskFormatter("NNN.NNN.NNN.NN");
        MaskTextWatcher mtwc = new MaskTextWatcher(Cfp, smfc);
        Cfp.addTextChangedListener(mtwc);


        TipoSanguineo = paciente.findViewById(R.id.tipo_sangue);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(paciente, R.array.Tipo_Sanguineo, android.R.layout.simple_spinner_item);
        TipoSanguineo.setAdapter(adapter);

        ps = new Paciente();
    }

    public Paciente obterPaciente()
    {
        ps.setNome(Nome.getText().toString());
        ps.setEndereco(Endereco.getText().toString());
        ps.setDataDeNascimento(DataDeNascimento.getText().toString());
        ps.setCpf(Cfp.getText().toString());
        ps.setTipoSanguineo(TipoSanguineo.getSelectedItem().toString());

        return ps;
    }


}
