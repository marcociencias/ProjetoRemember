package com.example.alarme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.provider.SyncStateContract;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Toast;

import DAO.TarefaDAO;
import Modelo.Login;
import Modelo.Tarefas;

public class FormularioActivity extends AppCompatActivity {

    FormularioHelper helper;
    private Login logado;
    private long id;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_formulario);

        helper = new FormularioHelper(this);
        logado = (Login) getApplicationContext();
        id = logado.getId();
        Toast.makeText(this, "Usuario logado" + id, Toast.LENGTH_SHORT).show();

        Intent intent = getIntent();
        Tarefas tarefas = (Tarefas) intent.getSerializableExtra("tarefa");

        if(tarefas != null)
        {
            helper.preencheFormulario(tarefas);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_formulario, menu);
        return super.onCreateOptionsMenu(menu);
    }

    public void CadastrarTarefa(View view) {
        Tarefas tarefa = new Tarefas();
        tarefa = helper.pegaTarefa();

        Toast.makeText(this,"Tarefa = " + tarefa.getTipo(),Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"Horario = " + tarefa.getHorario(),Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"Descricao = " + tarefa.getDescricao(),Toast.LENGTH_SHORT).show();
        Toast.makeText(this,"Id Login = " + id,Toast.LENGTH_SHORT).show();

        TarefaDAO dao = new TarefaDAO(this);
        dao.insere(tarefa,id);
        dao.close();
        finish();

        Toast.makeText(this, "Inserido com sucesso", Toast.LENGTH_SHORT).show();
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()){
            case R.id.menu_formulario_ok:
                Tarefas tarefa = helper.pegaTarefa();
                TarefaDAO dao = new TarefaDAO(this);
                if(tarefa.getId() != null)
                {
                    dao.alterar(tarefa);
                    Toast.makeText(FormularioActivity.this, "Tarefa " + tarefa.getTipo() + " foi alterado", Toast.LENGTH_SHORT).show();
                }else {
                    dao.insere(tarefa,id);
                    Toast.makeText(FormularioActivity.this, "Tarefa " + tarefa.getTipo() + " foi salvo", Toast.LENGTH_SHORT).show();
                }
                dao.close();
                finish();
                break;
        }
        return super.onOptionsItemSelected(item);
    }
}
