package com.example.alarme;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.app.job.JobInfo;
import android.app.job.JobScheduler;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import java.util.List;

import DAO.TarefaDAO;
import Modelo.ListaTarefaAdapter;
import Modelo.Login;
import Modelo.Tarefas;

public class TarefasActivity extends AppCompatActivity {

    private ListView listaTarefas;
    private Login logado;
    private long id;
    List<Tarefas> arrayListTarefas;
    ListaTarefaAdapter arrayAdapterTarefa;
    private static final String TAG = "TarefaActivity";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tarefas);

        logado = (Login) getApplicationContext();
        id = logado.getId();

        listaTarefas = (ListView) findViewById(R.id.lista_tarefas);

        listaTarefas.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> lista, View item, int position, long id) {
                Tarefas tarefa = (Tarefas) listaTarefas.getItemAtPosition(position);
                Intent intentTrocaActivity = new Intent(TarefasActivity.this,FormularioActivity.class);
                intentTrocaActivity.putExtra("tarefa",tarefa);
                startActivity(intentTrocaActivity);
            }
        });

        Button novoAluno = findViewById(R.id.botao);
        novoAluno.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intentFormulario = new Intent(TarefasActivity.this, FormularioActivity.class);
                startActivity(intentFormulario);
            }
        });

        registerForContextMenu(listaTarefas);
    }

    private void carregaLista() {

        TarefaDAO dao = new TarefaDAO(this);
        arrayListTarefas =  dao.bucarTarefas(id);
        dao.close();
        arrayAdapterTarefa = new ListaTarefaAdapter(getApplicationContext(), arrayListTarefas);
        listaTarefas.setAdapter(arrayAdapterTarefa);
    }

    protected void onResume(){
        super.onResume();
        carregaLista();
    }
    public void onCreateContextMenu(ContextMenu menu, View v, final ContextMenu.ContextMenuInfo menuInfo) {
        MenuItem deletar = menu.add("Deletar");
        deletar.setOnMenuItemClickListener(new MenuItem.OnMenuItemClickListener() {
            @Override
            public boolean onMenuItemClick(MenuItem menuItem) {

                AdapterView.AdapterContextMenuInfo info = (AdapterView.AdapterContextMenuInfo) menuInfo;

                Tarefas tarefa =  (Tarefas) listaTarefas.getItemAtPosition(info.position);
                Toast.makeText(TarefasActivity.this,"Tarefa" + tarefa.getTipo() + " removido com sucesso ",Toast.LENGTH_SHORT).show();

                TarefaDAO dao = new TarefaDAO(TarefasActivity.this);
                dao.deletar(tarefa);
                dao.close();
                // apos deletar o objeto é necessário carregar a lista novamente
                // pq ela não passa pelo metodo onResumo , ou seja
                // estamos ainda na mesma activy
                carregaLista();
                return false;
            }
        });
    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {

        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.acoes_start_tarefas, menu);
        return super.onCreateOptionsMenu(menu);
    }


    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        switch (item.getItemId()) {
            case R.id.menu_formulario_ok:

                JobScheduler _scheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                _scheduler.cancel(123);

                Toast.makeText(this,"Agenda vigente foi criada e será administrada",Toast.LENGTH_LONG).show();
                ComponentName componentName = new ComponentName(this, ExecutarTarefas.class);
                JobInfo info = new JobInfo.Builder(123, componentName)
                        .setRequiresCharging(false)
                        .setRequiredNetworkType(JobInfo.NETWORK_TYPE_NONE)
                        .setPersisted(true)
                        .setPeriodic(5000)
                        .setPersisted(true)
                        .setPeriodic(15 * 60 * 1000)
                        .build();

                JobScheduler scheduler = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                int resultCode = scheduler.schedule(info);

                if (resultCode == JobScheduler.RESULT_SUCCESS) {
                    Log.d(TAG, "Job Sucess");
                } else {
                    Log.d(TAG, "Falha");
                }
                break;

            case R.id.menu_formulario_cancel:
                Toast.makeText(this,"Agenda vigente foi cancelada",Toast.LENGTH_LONG).show();

                JobScheduler _scheduler2 = (JobScheduler) getSystemService(JOB_SCHEDULER_SERVICE);
                _scheduler2.cancel(123);

                Log.d(TAG, "Job cancelado");

                break;
        }

        return super.onOptionsItemSelected(item);
    }



}
