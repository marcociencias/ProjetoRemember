package com.example.alarme;

import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.Spinner;

import com.github.rtoshiro.util.format.SimpleMaskFormatter;
import com.github.rtoshiro.util.format.text.MaskTextWatcher;

import Modelo.Tarefas;

public class FormularioHelper {

    private Spinner Tarefa;
    private EditText Horario;
    private EditText Descricao;
    Tarefas tarefas;

    public FormularioHelper(FormularioActivity formularioActivity)
    {
        Tarefa = formularioActivity.findViewById(R.id.tipo_tarefa);
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(formularioActivity, R.array.Tipo_Tarefa, android.R.layout.simple_spinner_item);
        Tarefa.setAdapter(adapter);

        Horario = formularioActivity.findViewById(R.id.horario_tarefa);
        SimpleMaskFormatter smfc = new SimpleMaskFormatter("NN:NN");
        MaskTextWatcher mtwc = new MaskTextWatcher(Horario, smfc);
        Horario.addTextChangedListener(mtwc);

        Descricao = formularioActivity.findViewById(R.id.descricao_tarefa);

        tarefas = new Tarefas();
    }

    public void preencheFormulario(Tarefas tarefa)
    {
        ArrayAdapter<String> adapter = (ArrayAdapter<String>) Tarefa.getAdapter();
        int posicaoNoAdapter = adapter.getPosition(tarefa.getTipo());
        Tarefa.setSelection(posicaoNoAdapter);


        Horario.setText(tarefa.getHorario());
        Descricao.setText(tarefa.getDescricao());
        this.tarefas = tarefa;
    }


    public Tarefas pegaTarefa()
    {
        tarefas.setTipo(Tarefa.getSelectedItem().toString());
        tarefas.setHorario(Horario.getText().toString());
        tarefas.setDescricao(Descricao.getText().toString());

        return tarefas;
    }


}
