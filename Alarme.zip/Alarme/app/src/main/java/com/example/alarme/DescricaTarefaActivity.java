package com.example.alarme;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.os.Vibrator;
import android.telephony.SmsManager;
import android.view.ActionMode;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import DAO.ResponsavelDAO;
import Modelo.Paciente;
import Modelo.Responsavel;
import Modelo.Tarefas;

public class DescricaTarefaActivity extends AppCompatActivity {

    String titulo;
    String descricao;
    String horario;
    String responsavel;

    long id;

    TextView txtTitulo;
    TextView txtDescricao;
    TextView txtHorario;

    Bundle params;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_descrica_tarefa);

        Intent intent = getIntent();
       // intent.getExtras();

         titulo = intent.getStringExtra("Titulo");
         descricao = intent.getStringExtra("Descricao");
         horario = intent.getStringExtra("Horario");
         responsavel = intent.getStringExtra("Responsavel");

         id = Long.parseLong(responsavel);

         txtTitulo = findViewById(R.id.txtTitulo);
         txtDescricao = findViewById(R.id.txtDescricao);
         txtHorario = findViewById(R.id.txtHorario);

         txtTitulo.setText("TAREFA : " + titulo);
         txtHorario.setText("HORARIO : " + horario);
         txtDescricao.setText("DESCRIÇÃO : " + descricao);

    }

    public void Confirmar(View v)
    {

        if(ActivityCompat.checkSelfPermission(DescricaTarefaActivity.this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(DescricaTarefaActivity.this, new String[]
                    {Manifest.permission.SEND_SMS,}, 1000);
        }else{

        };

        //DAO para recuperar o telefone do responsavel para enviar a mensagem
        ResponsavelDAO dao = new ResponsavelDAO(this);
        Responsavel rp = new Responsavel();
        rp.setTelefone(dao.getResponsavel(id));
        Toast.makeText(this,"Telefone = " + rp.getTelefone(),Toast.LENGTH_SHORT).show();

        String numero = rp.getTelefone();
        String menssagem = descricao;

        try {
            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(numero, null, menssagem , null, null);
            Toast.makeText(getApplicationContext(),"enviado", Toast.LENGTH_LONG).show();;
        }catch (Exception e){
            Toast.makeText(getApplicationContext(),"erro", Toast.LENGTH_LONG).show();;
        }

        finishAffinity();
    }

}
