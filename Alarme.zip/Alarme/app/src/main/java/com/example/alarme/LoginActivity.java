package com.example.alarme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import DAO.LoginDAO;
import Modelo.Login;

public class LoginActivity extends AppCompatActivity {

    LoginDAO dao;
    LoginHelper helper;
    Login login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        helper = new LoginHelper(this);
    }

    public void getLogin(View view) {
       login = new Login();
       login = helper.pegaLogin();

       dao = new LoginDAO(this);
       long resultado = dao.getIdLogin(login);

       if(resultado == 0)
       {
           Toast.makeText(this, "Erro no Login", Toast.LENGTH_SHORT).show();
       }
       else
       {
           Login login = (Login) getApplicationContext();
           login.setId(resultado);
          Toast.makeText(this, "Bem vindo", Toast.LENGTH_SHORT).show();
          Intent intent = new Intent(LoginActivity.this,TarefasActivity.class);
          startActivity(intent);
       }
    }

    public void NovoCadastro(View view) {
            Intent intent = new Intent(LoginActivity.this, CadastroActivity.class);
            startActivity(intent);
    }
}
