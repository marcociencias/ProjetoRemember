package com.example.alarme;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

import Modelo.Cadastro;

public class CadastroActivity extends AppCompatActivity {

    CadastroHelper helper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);
    }

    public void NovoUser(View view) {

        helper = new CadastroHelper(this);
        Cadastro cadastro = helper.pegaCadastro();

        if(cadastro.getUsuario().equals("") || cadastro.getSenha().equals(""))
        {
            Toast.makeText(this,"Necessario informar o Usuario/Senha",Toast.LENGTH_LONG).show();
            return;
        }

        Intent intent = new Intent(CadastroActivity.this,PacienteActivity.class);
        intent.putExtra("cadastro",cadastro);
        startActivity(intent);
    }
}
