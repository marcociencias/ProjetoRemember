package com.example.alarme;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.job.JobParameters;
import android.app.job.JobService;
import android.content.Context;
import android.content.Intent;
import android.media.Ringtone;
import android.media.RingtoneManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Vibrator;
import android.util.Log;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import DAO.TarefaDAO;
import Modelo.Login;
import Modelo.Tarefas;

public class ExecutarTarefas extends JobService {

    private static final String TAG = "ExecutarTarefas";
    private boolean jobCancelled = false;
    private Login logado;
    private long id;
    List<Tarefas> arrayListTarefas;
    int contador = 0;

    //CANAL 1 - REMEDIO
    private final String CHANNEL_ID_R = "personal notifications 1";
    private final int NOTIFICATION_ID_R = 001;
    //CANAL 2 - CAFE DA MANHA
    private final String CHANNEL_ID_CDM = "personal notifications 2";
    private final int NOTIFICATION_ID_CDM = 002;
    //CANAL 3 - ALMOCO
    private final String CHANNEL_ID_ALM = "personal notifications 3";
    private final int NOTIFICATION_ID_ALM = 003;
    //CANAL 4 - CAFE DA TARDE
    private final String CHANNEL_ID_CDT = "personal notifications 4";
    private final int NOTIFICATION_ID_CDT = 004;
    //CANAL 5 - JANTAR
    private final String CHANNEL_ID_JT = "personal notifications 5";
    private final int NOTIFICATION_ID_JT = 005;

    //

    @Override
    public boolean onStartJob(JobParameters params) {
        Log.d(TAG,"Job started");
        logado = (Login) getApplicationContext();
        id = logado.getId();
        TarefaDAO dao = new TarefaDAO(this);
        arrayListTarefas =  dao.bucarTarefas(id);
        dao.close();
        doBackgroundWork(params,arrayListTarefas);
        return true;
    }

    private void doBackgroundWork(final JobParameters params , final List<Tarefas> tarefas) {

        new Thread(new Runnable() {
            @Override
            public void run() {
                    while (!jobCancelled)
                    {
                        Log.e(TAG,"Valor do contador =" + contador++);
                        for (int i = 0; i < tarefas.size() ; i++) {

                            String[] hora_atualizada = retornaHoraMinuto();
                            String[] hora_tarefa = tarefas.get(i).getHorario().split(":");
                            String tarefa = tarefas.get(i).getTipo();

                            if (hora_atualizada[0].equals(hora_tarefa[0]) &&  hora_atualizada[1].equals(hora_tarefa[1]))
                            {
                                if(tarefa.toUpperCase().equals("REMEDIO")) { NotificacaoRemedio(tarefas.get(i).getTipo(), tarefas.get(i).getDescricao() , tarefas.get(i).getHorario(),tarefas.get(i).getFk_id_logado());
                                }
                                else if(tarefa.toUpperCase().equals("CAFE DA MANHA")){
                                    NotificacaoCafeDaManha(tarefas.get(i).getTipo(), tarefas.get(i).getDescricao() , tarefas.get(i).getHorario(),tarefas.get(i).getFk_id_logado());
                                }
                                else if(tarefa.toUpperCase().equals("ALMOCO")){
                                    NotificacaoAlmoco(tarefas.get(i).getTipo(), tarefas.get(i).getDescricao(), tarefas.get(i).getHorario(),tarefas.get(i).getFk_id_logado());
                                }
                                else if(tarefa.toUpperCase().equals("CAFE DA TARDE")){
                                    NotificacaoCafeDaTarde(tarefas.get(i).getTipo(), tarefas.get(i).getDescricao(), tarefas.get(i).getHorario(),tarefas.get(i).getFk_id_logado());
                                }
                                else if(tarefa.toUpperCase().equals("JANTAR")){
                                    NotificacaoJantar(tarefas.get(i).getTipo(), tarefas.get(i).getDescricao(), tarefas.get(i).getHorario(),tarefas.get(i).getFk_id_logado());
                                }
                                try {
                                    Thread.sleep(60000);
                                } catch (InterruptedException e) {
                                    e.printStackTrace();
                                }
                            }
                            if (jobCancelled)
                                return;
                        }
                            try {
                                Thread.sleep(1000);
                            } catch (InterruptedException e) {
                                e.printStackTrace();
                            }
                    }
                Log.d(TAG,"Finalizado");
                jobFinished(params,false);
            }
        }).start();
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        Log.d(TAG,"Job cancelado - completado");
        Log.d(TAG,"Valor da variavel jobcancelled =" + jobCancelled);

        jobCancelled = true;
        return false;
    }

    public String[] retornaHoraMinuto()
    {
        SimpleDateFormat dateFormat_hora = new SimpleDateFormat("HH:mm");
        Date data = new Date();

        Calendar cal = Calendar.getInstance();
        cal.setTime(data);
        Date data_atual = cal.getTime();

        String hora_atual = dateFormat_hora.format(data_atual);
        Log.e("Hora",hora_atual);

        String [] horaSistema = hora_atual.split(":");

        return horaSistema;
    }


    public void DevolverDados(String titulo)
    {
        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        startActivity(i);
    }

    //Notificações e Canais//
    public void NotificacaoRemedio(String titulo , String descricao , String horario , long id)
    {
        CanalRemedio();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        i.putExtra("Descricao",descricao);
        i.putExtra("Horario",horario);
        i.putExtra("Responsavel",String.valueOf(id));

        PendingIntent p = PendingIntent.getActivity(getApplicationContext(),0,i,PendingIntent.FLAG_CANCEL_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID_R)
                .setTicker("NOTIFICAÇÃO")
                .setSmallIcon(R.drawable.remedio)
                .setContentTitle(titulo)
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Tomar mesmo viu"))
                .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                .setGroup("Voltar")
                .setContentIntent(p);

        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.addLine(horario);
        style.addLine(descricao);

        builder.setStyle(style);

        Notification n = builder.build();
        n.flags = Notification.FLAG_AUTO_CANCEL;
        nm.notify(NOTIFICATION_ID_R,n);

        try{
            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone toque = RingtoneManager.getRingtone(this,som);

            toque.play();
            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long milliseconds = 8000;
            vibrator.vibrate(milliseconds);

        }catch (Exception ex)
        {

        }
    }

    private void CanalRemedio()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence name = "Personal Notifications 1";
            String description = "Include all the person notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID_R,name,importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void NotificacaoCafeDaManha(String titulo , String descricao, String horario,long id)
    {
        CanalCafeDaManha();
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        i.putExtra("Descricao",descricao);
        i.putExtra("Horario",horario);
        i.putExtra("Responsavel",String.valueOf(id));

        PendingIntent p = PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_CANCEL_CURRENT);
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID_CDM)
                .setTicker("NOTIFICAÇÃO")
                .setSmallIcon(R.drawable.cafepq)
                .setContentTitle(titulo)
                //  .setContentText("Tomar remedio agora")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Tomar mesmo viu"))
                .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                .setContentIntent(p);

        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.addLine(horario);
        style.addLine(descricao);
        builder.setStyle(style);

        Notification n = builder.build();
        n.flags = Notification.FLAG_AUTO_CANCEL;
        nm.notify(NOTIFICATION_ID_CDM,n);

        try{
            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone toque = RingtoneManager.getRingtone(this,som);

            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long milliseconds = 8000;

            toque.play();
            vibrator.vibrate(milliseconds);

        }catch (Exception ex)
        {

        }
    }

    private void CanalCafeDaManha()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence name = "Personal Notifications 2";
            String description = "Include all the person notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID_CDM,name,importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void NotificacaoAlmoco(String titulo , String descricao , String horario,long id)
    {
        CanalAlmoco();

        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        i.putExtra("Descricao",descricao);
        i.putExtra("Horario",horario);
        i.putExtra("Responsavel",String.valueOf(id));

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        PendingIntent p = PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID_ALM)
                .setTicker("NOTIFICAÇÃO")
                .setSmallIcon(R.drawable.jantar)
                .setContentTitle(titulo)
                //  .setContentText("Tomar remedio agora")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Tomar mesmo viu"))
                .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                .setContentIntent(p);

        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.addLine(horario);
        style.addLine(descricao);

        builder.setStyle(style);

        Notification n = builder.build();
        n.flags = Notification.FLAG_AUTO_CANCEL;
        nm.notify(NOTIFICATION_ID_ALM,n);

        try{
            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone toque = RingtoneManager.getRingtone(this,som);

            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long milliseconds = 8000;

            toque.play();
            vibrator.vibrate(milliseconds);

        }catch (Exception ex)
        {

        }
    }

    private void CanalAlmoco()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence name = "Personal Notifications 3";
            String description = "Include all the person notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID_ALM,name,importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void NotificacaoCafeDaTarde(String titulo , String descricao ,String horario,long id)
    {
        CanalCafeDaTarde();

        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        i.putExtra("Descricao",descricao);
        i.putExtra("Horario",horario);
        i.putExtra("Responsavel",String.valueOf(id));

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        PendingIntent p = PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID_CDT)
                .setTicker("NOTIFICAÇÃO")
                .setSmallIcon(R.drawable.cafepq)
                .setContentTitle(titulo)
                //  .setContentText("Tomar remedio agora")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Tomar mesmo viu"))
                .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                .setContentIntent(p);

        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.addLine(horario);
        style.addLine(descricao);
        builder.setStyle(style);

        Notification n = builder.build();
        n.flags = Notification.FLAG_AUTO_CANCEL;
        nm.notify(NOTIFICATION_ID_CDT,n);

        try{
            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone toque = RingtoneManager.getRingtone(this,som);

            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long milliseconds = 8000;

            toque.play();
            vibrator.vibrate(milliseconds);

        }catch (Exception ex)
        {

        }
    }

    private void CanalCafeDaTarde()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence name = "Personal Notifications 4";
            String description = "Include all the person notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID_CDT,name,importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

    public void NotificacaoJantar(String titulo , String descricao , String horario,long id)
    {
        CanalJantar();

        Intent i = new Intent(this,DescricaTarefaActivity.class);
        i.putExtra("Titulo",titulo);
        i.putExtra("Descricao",descricao);
        i.putExtra("Horario",horario);
        i.putExtra("Responsavel",String.valueOf(id));

        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        PendingIntent p = PendingIntent.getActivity(this,0,i,PendingIntent.FLAG_CANCEL_CURRENT);

        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, CHANNEL_ID_JT)
                .setTicker("NOTIFICAÇÃO")
                .setSmallIcon(R.drawable.jantar)
                .setContentTitle(titulo)
                //  .setContentText("Tomar remedio agora")
                .setStyle(new NotificationCompat.BigTextStyle().bigText("Tomar mesmo viu"))
                .setPriority(NotificationManager.IMPORTANCE_DEFAULT)
                .setContentIntent(p);

        NotificationCompat.InboxStyle style = new NotificationCompat.InboxStyle();
        style.addLine(horario);
        style.addLine(descricao);

        builder.setStyle(style);

        Notification n = builder.build();
        n.flags = Notification.FLAG_AUTO_CANCEL;
        nm.notify(NOTIFICATION_ID_JT,n);

        try{
            Uri som = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);
            Ringtone toque = RingtoneManager.getRingtone(this,som);

            Vibrator vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long milliseconds = 8000;

            toque.play();
            vibrator.vibrate(milliseconds);

        }catch (Exception ex)
        {

        }
    }

    private void CanalJantar()
    {
        if(Build.VERSION.SDK_INT>=Build.VERSION_CODES.O)
        {
            CharSequence name = "Personal Notifications 5";
            String description = "Include all the person notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;

            NotificationChannel notificationChannel = new NotificationChannel(CHANNEL_ID_JT,name,importance);
            notificationChannel.setDescription(description);

            NotificationManager notificationManager = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            notificationManager.createNotificationChannel(notificationChannel);
        }
    }

}
